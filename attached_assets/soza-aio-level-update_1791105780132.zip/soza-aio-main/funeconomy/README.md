# Fun Economy (gaya OwO)

Mata uang: **cash** (saldo global per user, terpisah dari economy lama `.balance`).
Command diketik **tanpa titik**, langsung di chat. Semua pengaturan ada di `funeconomy/config.js`.

| Command | Alias | Fungsi |
|---|---|---|
| `scash` | bal, balance, money, credit, currency | Cek saldo |
| `sdaily` | | Hadiah harian + streak (reset 00:00 WIB) |
| `sgive @user <jumlah\|all>` | send | Kirim cash |
| `scf <jumlah\|all> [h/t]` | coinflip, coin, flip | Coin flip (menang = 2x) |
| `ss <jumlah\|all>` | slots, slot | Slots (lihat tabel di bawah) |
| `sbj <jumlah\|all>` | blackjack | Blackjack dengan tombol Hit/Stand. Ketik ulang `sbj` untuk melanjutkan game |
| `slottery [jumlah\|all]` | bet, lotto | Lottery harian, satu pool untuk semua server |
| `sdrop <jumlah\|all>` | | Taruh cash di channel |
| `spickup` | | Ambil semua cash yang di-drop di channel ini |
| `slb [kategori] [global] [1-25]` | leaderboard, rank, ranking | Ranking cash, streak, level, atau total cash per-server |
| `smy [kategori] [global]` | me | Posisi kamu di ranking |

Kategori ranking: `cash` (default), `daily`, `level`, `guild`. Tanpa `global` = server ini.
Contoh: `slb`, `slb global`, `slb daily 5`, `slb level g`, `slb guild`, `smy`, `smy cash global`.

- Cooldown **15 detik** per game untuk `ss`, `scf`, `sbj` (per user). Dipakai bersama command prefix dan slash; ubah di `COOLDOWNS` pada `config.js` (0 = mati).
- Taruhan minimal **1**, maksimal **250,000**. `all` = `min(saldo, 250,000)`.
- Slots (odds OwO, RTP 95%): 🍆🍆🍆 x1 (20%), ❤️❤️❤️ x2 (20%), 🍒🍒🍒 x3 (5%), cash x3 x4 (2.5%), ⭕🇼⭕ x10 (1%).
- Blackjack: menang 2x, seri = taruhan kembali, dealer berhenti di 17, tepat 21 otomatis stand.
- Lottery: peluang menang = taruhanmu / total pool, maksimal 250,000 per lottery per user. Undian otomatis setiap pergantian hari; pemenang menerima seluruh pool dan DM.
- `ss` tanpa angka diabaikan (supaya "ss" = screenshot di chat tidak memicu slots). Ubah lewat `SLOTS_REQUIRE_AMOUNT`.
- Ganti emoji (mis. emoji custom server) di `CASH_EMOJI`, `COIN`, `SLOT_EMOJI`, dan `SLOT_SPINNING`.
- Ranking per-server memakai server tempat user memakai command, lalu mengisi akun lama dari daftar anggota saat ranking server dibuka.

## Level

Seperti OwO: ngobrol di chat memberi XP, naik level memberi cash. Hanya untuk akun yang sudah terdaftar.

| Command | Alias | Fungsi |
|---|---|---|
| `slevel [@user]` | lvl, xp | Lihat level, progres XP, XP hari ini, dan hadiah berikutnya |
| `slevelup [on\|off]` | lvlup | Nyalakan/matikan pesan level up di server (perlu izin Manage Server) |

- Chat: **10-15 XP per menit** (jeda 60 detik per user), maksimal **3,000 XP/hari** dari chat.
- Bonus **500 XP** untuk pesan pertama tiap hari dan **100 XP** saat `sdaily` berhasil (keduanya di luar batas 3,000, jadi maksimal 3,600/hari).
- Tidak dihitung: command bot (prefix `s` maupun `.`), pesan lebih pendek dari 3 karakter, pesan yang sama persis dengan pesan terakhir yang dihitung, bot, dan DM.
- Hadiah naik level: **5,000 x nomor level** (level 14 = 70,000). Langsung masuk saldo, walau pesan level up dimatikan.
- Rumus XP dari level L ke L+1: `10 x L^2 + 100 x L + 200` (level 2 = 310 XP, level 10 = 9,150 XP total, level 50 = 536,550 XP total).
  Rumus OwO tidak ada di dokumentasi publik, jadi angka ini buatan sendiri dan bisa diubah di `LEVELING.FORMULA`.
- `slb level` dan `smy level` memakai level ini.
- Semua angka di blok `LEVELING` pada `config.js` (`ENABLED: false` mematikan seluruh fitur).

## Registrasi akun

Semua command economy (prefix `s`, slash `/economy`, dan `/fun slots|coinflip|lottery|blackjack`) membutuhkan akun aktif.
Pengguna yang belum terdaftar melihat kartu Welcome dengan tombol Register; setelah ditekan, akun aktif dan menerima bonus
**250.000 cash**. Command lain di bot tidak terpengaruh.

- Hanya pemilik kartu yang bisa menekan tombolnya. Bonus diberikan tepat sekali per pengguna.
- Untuk prefix, kartu muncul maksimal sekali per `PROMPT_COOLDOWN_MS` per pengguna. `ss` tanpa angka tidak memicu kartu.
- `sgive` / `/economy give` ke pengguna yang belum terdaftar ditolak.
- Pemain lama yang sudah punya saldo atau pernah `daily` otomatis dianggap terdaftar tanpa bonus. Migrasi ini berjalan
  sekali saat command economy pertama dipakai; matikan lewat `GRANDFATHER_EXISTING: false`.
- Pengaturan tersedia di `REGISTRATION` pada `config.js`: `ENABLED`, `BONUS`, `GRANDFATHER_EXISTING`, `PROMPT_COOLDOWN_MS`.

## Struktur
- `events/funEconomy.js` - listener `messageCreate` (dimuat otomatis oleh `handlers/events.js`)
- `funeconomy/index.js` - dispatcher prefix `s` + loader command
- `funeconomy/commands/*.js` - satu file per command (tambah file baru = command baru)
- `funeconomy/leveling.js` (rumus) + `funeconomy/levelUp.js` (XP chat & pengumuman) + `models/funeconomy/level.js` (database)
- `events/funEconomyLevel.js` - XP dari obrolan
- `funeconomy/register.js` - kartu & tombol Register, `models/funeconomy/registration.js` - logika akun
- `events/funEconomyInteraction.js` - tombol blackjack & Register; `events/funEconomyReady.js` - jadwal lottery
- `models/funeconomy/` - schema & operasi database (taruhan diproses atomik)

## Slash commands

Perintah slash memakai saldo cash global yang sama:

- `/economy balance [user]`
- `/economy daily`
- `/economy slots bet`
- `/economy coinflip bet side`
- `/economy give user amount`
- `/economy leaderboard`
- `/fun slots bet` dan `/fun coinflip bet side` juga memakai saldo cash baru.

Perintah lama `/economy work`, `beg`, `deposit`, `withdraw`, serta `/fun lottery` dan
`blackjack` tidak lagi didaftarkan. Jalankan ulang bot agar Discord memperbarui daftar slash command.

## Perintah pembuat bot

`/addcash user amount` menambahkan hingga 1.000.000.000 cash ke pengguna. Isi `DISCORD_USER_ID`
dengan Discord user ID pembuat bot. Isi juga `DISCORD_GUILD_ID` di Railway dengan ID server tempat
command tersedia. Command hanya didaftarkan di server itu, dibatasi ke admin oleh Discord, lalu bot
memeriksa ID pemilik sebelum menambah saldo. Untuk menyembunyikannya dari admin lain juga, batasi
`/addcash` ke pengguna pembuat bot di **Server Settings → Integrations → bot → Commands**.

Command slash lainnya tetap didaftarkan secara global. Pemisahan ini menjaga jumlah global di bawah
batas 100 command Discord.
