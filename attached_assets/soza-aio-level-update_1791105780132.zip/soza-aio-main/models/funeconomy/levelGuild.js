const mongoose = require('mongoose');

// Pengaturan level per server: apakah pesan "level up" ditampilkan. Hadiah tetap masuk saldo walau pesan dimatikan.
const levelGuildSchema = new mongoose.Schema({
    guildId: { type: String, required: true, unique: true },
    announce: { type: Boolean, default: true }
}, { timestamps: true });

module.exports = mongoose.models.FunLevelGuild || mongoose.model('FunLevelGuild', levelGuildSchema);
