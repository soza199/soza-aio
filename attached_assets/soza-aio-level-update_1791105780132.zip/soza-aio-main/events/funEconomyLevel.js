const { handleChat } = require('../funeconomy/levelUp');

// XP level dari obrolan. Dimuat otomatis oleh handlers/events.js (satu pendengar messageCreate tambahan).
module.exports = {
    name: 'messageCreate',
    async execute(message) {
        try {
            await handleChat(message);
        } catch (error) {
            console.error('[FUNECONOMY] Chat XP error:', error);
        }
    }
};
