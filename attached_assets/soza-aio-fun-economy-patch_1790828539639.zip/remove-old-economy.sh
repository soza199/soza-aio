#!/bin/sh
# Jalankan dari root repo (folder yang berisi index.js). Menghapus economy lama berprefix ".".
set -e
[ -d excesscommands/economy ] || { echo "Folder excesscommands/economy tidak ditemukan / sudah terhapus."; exit 0; }
if [ -d .git ]; then git rm -r -q excesscommands/economy; else rm -rf excesscommands/economy; fi
echo "OK: excesscommands/economy dihapus."
