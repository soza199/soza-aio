const { BUTTON_PREFIX, handleButton } = require('../funeconomy/blackjack');
const register = require('../funeconomy/register');

// Tombol blackjack (Hit/Stand) dan tombol Register. Dimuat otomatis oleh handlers/events.js.
// Keduanya stateless (disimpan di database / customId), jadi tetap bekerja setelah bot restart.
module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {
        if (!interaction.isButton()) return;

        if (interaction.customId.startsWith(`${register.BUTTON_PREFIX}:`)) {
            return register.handleButton(interaction);
        }
        if (interaction.customId.startsWith(`${BUTTON_PREFIX}:`)) {
            return handleButton(interaction, client);
        }
    }
};
