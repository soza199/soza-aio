const mongoose = require('mongoose');

// Penyimpan nilai kecil untuk fun economy: penanda migrasi registrasi dan penghitung nomor akun.
const metaSchema = new mongoose.Schema({
    key: { type: String, required: true, unique: true },
    value: { type: Number, default: 0 }
}, { timestamps: true });

module.exports = mongoose.models.FunEconomyMeta || mongoose.model('FunEconomyMeta', metaSchema);
