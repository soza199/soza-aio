const cfg = require('../../funeconomy/config');
const FunEconomy = require('./schema');
const Meta = require('./meta');
const { ensureAccount } = require('./economy');

const DUPLICATE_KEY = 11000;
const MIGRATION_KEY = 'registration-migrated';
const COUNTER_KEY = 'account-counter';
const CACHE_LIMIT = 100000;

// Registrasi tidak pernah dicabut, jadi hasil "sudah terdaftar" aman di-cache di memori.
const registeredCache = new Set();
let migration = null;

const remember = (userId) => {
    if (registeredCache.size >= CACHE_LIMIT) registeredCache.clear();
    registeredCache.add(userId);
};

/** findOneAndUpdate+upsert pada key unik: ulangi sekali kalau dua proses berebut membuat dokumen. */
async function upsertMeta(key, update, options) {
    for (let attempt = 0; attempt < 2; attempt++) {
        try {
            return await Meta.findOneAndUpdate({ key }, update, { upsert: true, ...options }).lean();
        } catch (error) {
            if (error?.code !== DUPLICATE_KEY || attempt === 1) throw error;
        }
    }
}

/**
 * Sekali seumur hidup: akun lama yang sudah punya aktivitas (saldo atau daily) dianggap sudah
 * terdaftar tanpa bonus, supaya pemain lama tidak diminta register ulang. Aman diulang (idempoten).
 */
async function runMigration() {
    if (await Meta.exists({ key: MIGRATION_KEY })) return;

    await FunEconomy.updateMany(
        {
            registeredAt: null,
            $or: [{ cash: { $gt: 0 } }, { dailyStreak: { $gt: 0 } }, { lastDailyDay: { $gte: 0 } }]
        },
        { $set: { registeredAt: new Date() } }
    );

    // Nomor akun berikutnya dilanjutkan dari jumlah akun yang sudah ada
    const total = await FunEconomy.countDocuments({ registeredAt: { $ne: null } });
    await upsertMeta(COUNTER_KEY, { $setOnInsert: { value: total } }, { new: false });
    await upsertMeta(MIGRATION_KEY, { $setOnInsert: { value: Date.now() } }, { new: false });
}

function ensureMigrated() {
    if (!cfg.REGISTRATION.ENABLED || !cfg.REGISTRATION.GRANDFATHER_EXISTING) return Promise.resolve();
    if (!migration) {
        migration = runMigration().catch((error) => {
            migration = null; // coba lagi pada command berikutnya
            throw error;
        });
    }
    return migration;
}

/** Apakah user sudah punya akun fun economy aktif? */
async function isRegistered(userId) {
    if (!cfg.REGISTRATION.ENABLED || registeredCache.has(userId)) return true;
    await ensureMigrated();
    const doc = await FunEconomy.findOne({ userId }).select('registeredAt').lean();
    if (!doc?.registeredAt) return false;
    remember(userId);
    return true;
}

/**
 * Aktifkan akun dan beri bonus. ATOMIK: hanya satu pemanggil yang berhasil per user, jadi klik
 * ganda atau dua tombol lama tidak bisa memberi bonus dua kali.
 * Return { created: false } kalau sudah terdaftar, atau { created: true, cash, bonus, accountNumber }.
 */
async function register(userId, guildId = null) {
    await ensureMigrated();
    await ensureAccount(userId);

    const bonus = cfg.REGISTRATION.BONUS;
    const update = { $set: { registeredAt: new Date() }, $inc: { cash: bonus } };
    if (guildId) update.$addToSet = { guildIds: guildId };

    const doc = await FunEconomy.findOneAndUpdate({ userId, registeredAt: null }, update, { new: true }).lean();
    remember(userId);
    if (!doc) return { created: false };

    // Nomor akun hanya hiasan: kegagalan di sini tidak boleh membatalkan registrasi
    let accountNumber = null;
    try {
        const counter = await upsertMeta(COUNTER_KEY, { $inc: { value: 1 } }, { new: true });
        accountNumber = counter.value;
        await FunEconomy.updateOne({ userId }, { $set: { accountNumber } });
    } catch (error) {
        console.error('[FUNECONOMY] Could not assign account number:', error.message);
    }

    return { created: true, cash: doc.cash, bonus, accountNumber };
}

module.exports = {
    isRegistered, register, ensureMigrated,
    // diekspor untuk pengujian
    _internals: { registeredCache, resetMigration: () => { migration = null; } }
};
